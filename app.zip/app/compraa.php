<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class compraa extends Model
{
    //
}
