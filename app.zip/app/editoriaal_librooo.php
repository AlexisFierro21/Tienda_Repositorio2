<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class editoriaal_librooo extends Model
{
    
	protected $fillable =['id','editoriaal_id','librooo_id'];
}
