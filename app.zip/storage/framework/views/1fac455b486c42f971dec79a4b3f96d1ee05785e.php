<?php $__env->startSection('content'); ?>
<div class="container text-center">
	<section id="libros">
		<?php $__currentLoopData = $libros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $libro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<article class="libro white-panel">
			<h3><?php echo e($libro->titulo); ?></h3><hr>
			<img src="<?php echo e($libro->image); ?>" width="150">
				<div class="libro-info panel">
				<p><?php echo e($libro->autor); ?></p>
				<h3><span class="label label-success">Precio : $<?php echo e(number_format($libro->precio,2)); ?></span>
				</h3>
				<p>
					<a class="btn btn-warning btn-tex" href="<?php echo e(route('cart-add',$libro->id)); ?>"><i class="fa fa-cart-plus fa-1x"></i> La quiero</a>
					<a class="btn btn-primary btn-tex" href="<?php echo e(route('libro-deta',$libro->id)); ?>"><i class="fa fa-chevron-circle-right fa-1x"></i> Leer mas</a><!--Esta linea es para generar la ruta con el id del libro seleccionado-->
				</p>

				</div>
			</article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</section>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('store.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>