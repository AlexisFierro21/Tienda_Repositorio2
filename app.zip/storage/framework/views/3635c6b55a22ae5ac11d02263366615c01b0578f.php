<?php $__env->startSection('content'); ?>
<div class="container text-center">
	<div class="page-header">
		<h2 class="titulo-librit">Editorial</h2>
	</div>
<div class="tabla-cart">
<?php if(count($res)): ?>
<div class="table-responsive">
	<table class="table table-stripped table-hover table-border">
	<thead>
		<tr>
			<th>Titulo</th>
			<th>Autor</th>
			<th>Precio</th>
			<th>Eliminar</th>
		</tr>
	</thead>
		<tbody>
		<?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
		<td><?php echo e($item->titulo); ?></td>
		<td><?php echo e($item->autor); ?></td>
		<td>$<?php echo e(number_format($item->precio,2)); ?></td>
		<td>
			<a href="<?php echo e(route('edit-delete',$item->id)); ?>" class="btn btn-danger">
				<i class="fa fa-remove"></i>
			</a>
		</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</tbody>
	</table><hr>
</div>
<?php else: ?>
<h3><span class=" main-title">No hay productos agregados</span></h3>
<?php endif; ?>
</div>
<br>
<div class="btn-group btn-group-justified " role="group" ariable="Justified button group">
<a href="<?php echo e(route('agregar-libro')); ?>" class="btn btn-primary rad"><i class="fa fa-chevron-circle-left fa-2x"> Agregar Libro</i></a>
</div>





</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('store.editorial.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>