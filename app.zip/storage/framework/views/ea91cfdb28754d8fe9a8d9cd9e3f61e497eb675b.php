<?php $__env->startSection('content'); ?>
<div class="container text-center">
	<div class="page-header">
		<h2 class="titulo-librit"><?php echo e($resultado->titulo); ?></h2>
	</div>
		<div class="row">
			<div class="col-md-6">
				<div class="libro-bloc">
					<img class="showww" src="../<?php echo e($resultado->image); ?> " width="150">	
				</div>
			</div>
			<div class="col-md-6">	
				<div class="libro-bloc">
					<h3><?php echo e($resultado->titulo); ?></h3>
					<div class="libro-info panel">
						<p><div class="container justi"><?php echo e($resultado->reseña); ?></div></p>
						<h3>
						<span class="label label-success">Precio : $<?php echo e(number_format($resultado->precio,2)); ?></span>
							</h3>
						<p>
							<h3><a class="btn btn-default btn-lg btn-block" href="<?php echo e(route('cart-add',$resultado->id)); ?>"><i class="fa fa-cart-plus"> La quiero</i></a></h3>
						</p>
					</div>
				</div>
			</div>
		</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('store.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>